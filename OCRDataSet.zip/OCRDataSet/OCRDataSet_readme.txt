The dataset is comprises a big matrix with 36 000 rows and 50 columns, representing 36 characters (20 images per character).

Rows 1:50 contain the first instance of character "a".
Rows 51:100 contain the second instace of character "a".
...
Rows 950:1000 contain the twentyth instance of character "a".
Rows 1001:1050 contain the first instance of character "b".
...
 

